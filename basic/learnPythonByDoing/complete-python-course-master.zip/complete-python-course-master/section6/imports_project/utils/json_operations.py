import json


def dict_to_json(d):
    return json.dumps(d)

print(f'json_operations is {__name__}')