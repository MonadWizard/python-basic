class AllBooksPageLocators:
    BOOKS = 'div.page_inner section li.col-xs-6.col-sm-4.col-md-3.col-lg-3'
    PAGER = 'div.page_inner section ul.pager li.current'
