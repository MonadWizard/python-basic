class QuotesPageLocators:
    QUOTE = 'div.quote'
