from animal import Animal
from dog import Dog

d = Dog('Bob')
# a = Animal()

d.walk()