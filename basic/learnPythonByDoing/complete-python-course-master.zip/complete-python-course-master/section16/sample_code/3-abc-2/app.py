from dog import Dog
from monkey import Monkey

d = Dog('Bob')
m = Monkey('Rolf')

d.walk()
m.eat()