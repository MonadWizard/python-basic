from animal import Animal


class Dog(Animal):
    def num_legs(self):
        return 4