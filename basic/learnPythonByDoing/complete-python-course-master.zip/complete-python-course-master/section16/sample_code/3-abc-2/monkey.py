from animal import Animal


class Monkey(Animal):
    def num_legs(self):
        return 2